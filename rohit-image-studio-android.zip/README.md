# Rohit Image Studio – Android

A native Android photo editor starter project. It uses a portrait-first mobile layout and edits images locally on the device.

## Current features
- Open a photo from the device
- Add movable text and symbol stickers
- Change selected text colour and size
- Rotate photo in 90-degree steps
- Toggle black-and-white preview
- Undo/redo for text/effect changes
- Export PNG to `Pictures/Rohit Image Studio`

## Build APK using GitHub Actions (phone-friendly)
1. Create a new public or private GitHub repository.
2. Upload the contents of this project (the files inside this folder, not the ZIP itself).
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Open **Build Android APK** and tap **Run workflow**. A push to `main` or `master` also starts a build.
5. When the run finishes, open it and download the `Rohit-Image-Studio-APK` artifact.
6. Extract the downloaded artifact ZIP and install `app-debug.apk`.

## Important
This is a working starter editor, not yet a full PixelLab replacement. Advanced features such as multi-layer image compositing, crop handles, background removal, custom font packs, blend modes, masks, and a full sticker library need additional implementation.
