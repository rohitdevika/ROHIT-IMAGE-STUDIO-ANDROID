package com.rohitdevika.imagestudio

import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.graphics.*
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.*
import java.io.OutputStream
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var editor: EditorView
    private lateinit var status: TextView
    private val pickImage = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 17, 31)
        window.navigationBarColor = Color.rgb(12, 17, 31)
        window.decorView.systemUiVisibility = 0

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(12, 17, 31))
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(18, 26, 45))
        }
        val title = TextView(this).apply {
            text = "ROHIT IMAGE STUDIO"
            textSize = 17f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        top.addView(title, LinearLayout.LayoutParams(0, dp(42), 1f))
        top.addView(topButton("↶") { editor.undo() })
        top.addView(topButton("↷") { editor.redo() })
        top.addView(topButton("SAVE") { saveImage() })
        page.addView(top)

        status = TextView(this).apply {
            text = "Choose a photo to start editing"
            textSize = 12f
            setTextColor(Color.rgb(170, 184, 210))
            setPadding(dp(16), dp(7), dp(16), dp(7))
        }
        page.addView(status)

        editor = EditorView(this)
        page.addView(editor, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f
        ).apply { setMargins(dp(10), dp(5), dp(10), dp(5)) })

        val tools = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(7), dp(8), dp(7), dp(10))
            setBackgroundColor(Color.rgb(18, 26, 45))
        }
        val scroller = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(tools)
        }
        val toolItems = listOf(
            "Photo" to { openPhoto() },
            "Text" to { addText() },
            "Sticker" to { addSticker() },
            "Color" to { changeTextColor() },
            "Size" to { changeTextSize() },
            "Rotate" to { editor.rotateImage() },
            "B&W" to { editor.toggleGray() },
            "Delete" to { editor.deleteSelected() }
        )
        toolItems.forEach { (label, action) ->
            tools.addView(toolButton(label, action))
        }
        page.addView(scroller)
        val hint = TextView(this).apply {
            text = "Tap an item to select • Drag to move • Pinch-free mobile editing"
            textSize = 10f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(135, 151, 180))
            setPadding(dp(8), dp(5), dp(8), dp(8))
            setBackgroundColor(Color.rgb(18, 26, 45))
        }
        page.addView(hint)
        setContentView(page)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun topButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = if (label == "SAVE") 12f else 22f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setPadding(dp(10), dp(7), dp(10), dp(7))
        setOnClickListener { action() }
    }

    private fun toolButton(label: String, action: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 12f
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setPadding(dp(15), dp(13), dp(15), dp(13))
        background = android.graphics.drawable.GradientDrawable().apply {
            setColor(Color.rgb(34, 49, 78))
            cornerRadius = dp(13).toFloat()
            setStroke(dp(1), Color.rgb(54, 73, 108))
        }
        val lp = LinearLayout.LayoutParams(-2, dp(48))
        lp.setMargins(dp(4), 0, dp(4), 0)
        layoutParams = lp
        setOnClickListener { action() }
    }

    private fun openPhoto() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "image/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(intent, pickImage)
    }

    @Deprecated("Deprecated Android callback retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickImage && resultCode == RESULT_OK) {
            data?.data?.let {
                try {
                    contentResolver.openInputStream(it)?.use { stream ->
                        val bitmap = BitmapFactory.decodeStream(stream)
                        if (bitmap != null) {
                            editor.setPhoto(bitmap)
                            status.text = "Photo loaded • Add text, stickers or effects"
                        }
                    }
                } catch (_: Exception) {
                    status.text = "Could not open this image"
                }
            }
        }
    }

    private fun addText() {
        val input = EditText(this).apply { hint = "Enter your text" }
        AlertDialog.Builder(this)
            .setTitle("Add text")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isNotEmpty()) editor.addText(value)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun addSticker() {
        val choices = arrayOf("★ Star", "♥ Heart", "● Circle", "◆ Diamond")
        AlertDialog.Builder(this).setTitle("Add sticker")
            .setItems(choices) { _, which ->
                editor.addSticker(listOf("★", "♥", "●", "◆")[which])
            }.show()
    }

    private fun changeTextColor() {
        val colors = intArrayOf(Color.WHITE, Color.YELLOW, Color.RED, Color.CYAN, Color.GREEN, Color.MAGENTA, Color.BLACK)
        val names = arrayOf("White", "Yellow", "Red", "Cyan", "Green", "Magenta", "Black")
        AlertDialog.Builder(this).setTitle("Text colour")
            .setItems(names) { _, which -> editor.setSelectedColor(colors[which]) }.show()
    }

    private fun changeTextSize() {
        val bar = SeekBar(this).apply { max = 100; progress = 35 }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(10), dp(22), dp(5))
            addView(bar)
        }
        AlertDialog.Builder(this).setTitle("Text size")
            .setView(box)
            .setPositiveButton("Apply") { _, _ -> editor.setSelectedSize(18f + bar.progress * 1.2f) }
            .setNegativeButton("Cancel", null).show()
    }

    private fun saveImage() {
        val bitmap = editor.renderExport() ?: run {
            status.text = "Add a photo before exporting"
            return
        }
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "RohitStudio_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Rohit Image Studio")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            status.text = "Export failed"
            return
        }
        try {
            contentResolver.openOutputStream(uri)?.use { out: OutputStream ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            status.text = "Saved to Pictures / Rohit Image Studio"
            Toast.makeText(this, "Image exported successfully", Toast.LENGTH_SHORT).show()
        } catch (_: Exception) {
            status.text = "Could not save image"
        }
    }
}

private data class TextItem(
    var text: String, var x: Float, var y: Float,
    var size: Float = 54f, var color: Int = Color.WHITE
)

private class EditorView(context: android.content.Context) : View(context) {
    private var photo: Bitmap? = null
    private val items = mutableListOf<TextItem>()
    private var selected = -1
    private var gray = false
    private var rotation = 0f
    private var downX = 0f
    private var downY = 0f
    private var moving = false
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val undoStack = ArrayDeque<Snapshot>()
    private val redoStack = ArrayDeque<Snapshot>()

    private data class Snapshot(val texts: List<TextItem>, val rotation: Float, val gray: Boolean)

    fun setPhoto(bitmap: Bitmap) {
        photo = bitmap
        items.clear()
        selected = -1
        rotation = 0f
        gray = false
        saveState()
        invalidate()
    }

    fun addText(value: String) {
        saveState()
        items.add(TextItem(value, width * .5f, height * .5f))
        selected = items.lastIndex
        invalidate()
    }

    fun addSticker(value: String) = addText(value)
    fun setSelectedColor(color: Int) {
        if (selected >= 0) { saveState(); items[selected].color = color; invalidate() }
    }
    fun setSelectedSize(size: Float) {
        if (selected >= 0) { saveState(); items[selected].size = size; invalidate() }
    }
    fun deleteSelected() {
        if (selected >= 0) {
            saveState()
            items.removeAt(selected)
            selected = -1
            invalidate()
        }
    }
    fun rotateImage() { saveState(); rotation = (rotation + 90f) % 360f; invalidate() }
    fun toggleGray() { saveState(); gray = !gray; invalidate() }

    private fun saveState() {
        undoStack.addLast(Snapshot(items.map { it.copy() }, rotation, gray))
        if (undoStack.size > 25) undoStack.removeFirst()
        redoStack.clear()
    }
    fun undo() {
        if (undoStack.isNotEmpty()) {
            redoStack.addLast(Snapshot(items.map { it.copy() }, rotation, gray))
            val s = undoStack.removeLast()
            items.clear(); items.addAll(s.texts.map { it.copy() })
            rotation = s.rotation; gray = s.gray; selected = -1; invalidate()
        }
    }
    fun redo() {
        if (redoStack.isNotEmpty()) {
            undoStack.addLast(Snapshot(items.map { it.copy() }, rotation, gray))
            val s = redoStack.removeLast()
            items.clear(); items.addAll(s.texts.map { it.copy() })
            rotation = s.rotation; gray = s.gray; selected = -1; invalidate()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(7, 12, 24))
        val b = photo
        if (b == null) {
            paint.color = Color.rgb(170, 184, 210)
            paint.textSize = 15f
            paint.textAlign = Paint.Align.CENTER
            canvas.drawText("Open a photo to start creating", width / 2f, height / 2f, paint)
            canvas.drawText("Your editing canvas", width / 2f, height / 2f + 25f, paint)
            return
        }
        val save = canvas.save()
        val fit = min(width.toFloat() / b.width, height.toFloat() / b.height)
        val dw = b.width * fit
        val dh = b.height * fit
        canvas.translate((width - dw) / 2f, (height - dh) / 2f)
        if (rotation != 0f) {
            canvas.rotate(rotation, dw / 2f, dh / 2f)
        }
        val src = Rect(0, 0, b.width, b.height)
        val dst = RectF(0f, 0f, dw, dh)
        val oldFilter = paint.colorFilter
        if (gray) {
            val matrix = ColorMatrix().apply { setSaturation(0f) }
            paint.colorFilter = ColorMatrixColorFilter(matrix)
        }
        canvas.drawBitmap(b, src, dst, paint)
        paint.colorFilter = oldFilter
        canvas.restoreToCount(save)

        val scale = min(width.toFloat() / b.width, height.toFloat() / b.height)
        val offsetX = (width - b.width * scale) / 2f
        val offsetY = (height - b.height * scale) / 2f
        items.forEachIndexed { index, item ->
            paint.color = item.color
            paint.textSize = item.size * resources.displayMetrics.density * .55f
            paint.typeface = Typeface.create("sans-serif", Typeface.BOLD)
            paint.textAlign = Paint.Align.CENTER
            paint.setShadowLayer(3f, 1f, 2f, Color.BLACK)
            val x = offsetX + item.x * scale
            val y = offsetY + item.y * scale
            canvas.drawText(item.text, x, y, paint)
            paint.clearShadowLayer()
            if (index == selected) {
                val w = paint.measureText(item.text)
                paint.color = Color.CYAN
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 2f
                canvas.drawRect(x - w / 2 - 8, y - item.size * .55f, x + w / 2 + 8, y + 9, paint)
                paint.style = Paint.Style.FILL
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val b = photo ?: return true
        val scale = min(width.toFloat() / b.width, height.toFloat() / b.height)
        val ox = (width - b.width * scale) / 2f
        val oy = (height - b.height * scale) / 2f
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = event.x; downY = event.y
                selected = -1
                items.indices.reversed().forEach { i ->
                    val x = ox + items[i].x * scale
                    val y = oy + items[i].y * scale
                    if (kotlin.math.abs(event.x - x) < 130 && kotlin.math.abs(event.y - y) < 90) {
                        selected = i
                        moving = true
                        return@forEach
                    }
                }
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> if (moving && selected >= 0) {
                items[selected].x = ((event.x - ox) / scale).coerceIn(0f, b.width.toFloat())
                items[selected].y = ((event.y - oy) / scale).coerceIn(0f, b.height.toFloat())
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP -> { moving = false; performClick(); return true }
        }
        return true
    }

    override fun performClick(): Boolean { super.performClick(); return true }

    fun renderExport(): Bitmap? {
        val b = photo ?: return null
        val output = Bitmap.createBitmap(b.width, b.height, Bitmap.Config.ARGB_8888)
        val c = Canvas(output)
        val p = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        c.save()
        c.rotate(rotation, b.width / 2f, b.height / 2f)
        if (gray) p.colorFilter = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
        c.drawBitmap(b, 0f, 0f, p)
        p.colorFilter = null
        c.restore()
        items.forEach { item ->
            p.color = item.color
            p.textSize = item.size
            p.typeface = Typeface.create("sans-serif", Typeface.BOLD)
            p.textAlign = Paint.Align.CENTER
            p.setShadowLayer(4f, 2f, 2f, Color.BLACK)
            c.drawText(item.text, item.x, item.y, p)
            p.clearShadowLayer()
        }
        return output
    }
}
